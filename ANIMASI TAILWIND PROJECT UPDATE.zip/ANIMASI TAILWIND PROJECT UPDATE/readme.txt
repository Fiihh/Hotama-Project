Bagian About Us fix pls

